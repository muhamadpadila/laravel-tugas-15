<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Jurusan;
use Illuminate\Support\Facades\Validator;

class JurusanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // DIGUNAKAN UNTUK MENAMPILKAN DATA Jurusan
        $jrs = Jurusan::all();
        if (isset($jrs)) {
            $hasil = [
                "message" => "Data Jurusan",
                "data" => $jrs
            ];
            return response()->json($hasil, 200);
        } else {
            $fails = [
                "message" => "Data Jurusan Tidak Ditemukan",
                "data" => $jrs
            ];
            return response()->json($fails, 404);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = [
            'nama_jurusan' => 'required',
            'singkatan_jurusan' => 'required',
            'jumlah_mahasantri' => 'required |integer ',
            
        ];

        $validator = Validator::make($request->all(), $data);

        if ($validator->fails()) {
            $fails = [
                "message" => "Gagal MenambahkanData Jurusan",
                "data" => $validator->errors()
            ];
            return response()->json($fails, 404);
        } else {
            $jrs = new Jurusan();
            $jrs->nama_jurusan = $request->nama_jurusan;
            $jrs->singkatan_jurusan = $request->singkatan_jurusan;
            $jrs->jumlah_mahasantri = $request->jumlah_mahasantri;
            $jrs->save();
            $success = [
                "message" => "Data Jurusan Berhasil Ditambahkan",
                "data" => $jrs
            ];
            return response()->json($success, 200);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = [
            'nama_jurusan' => 'required',
            'singkatan_jurusan' => 'required',
            'jumlah_mahasantri' => 'required |integer ',
            
        ];

        $validator = Validator::make($request->all(), $data);

        if ($validator->fails()) {
            $fails = [
                'message' => 'Data Tidak Valid',
                'data' => $validator->errors()
            ];
            return response()->json($fails, 400);
        } else {
            $jrs = new Jurusan;
            $jrs->nama_jurusan = $request->nama_jurusan;
            $jrs->singkatan_jurusan = $request->singkatan_jurusan;
            $jrs->jumlah_mahasantri = $request->jumlah_mahasantri;
            $jrs->save();
            $success = [
                'message' => 'Data Jurusan Berhasil ditambahkan',
                'data' => $jrs
            ];
            return response()->json($success, 200);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // DIGUNAKAN UNTUK MENGHAPUS MAHASANTRI
        $jrs = Jurusan::where('id', $id)->first();
        if (isset($jrs)) {
            $jrs->delete();
            $success = [
                "message" => "Data jurusan Berhasil Dihapus",
                "data" => $jrs
            ];
            return response()->json($success, 200);
        } else {
            $fails = [
                "message" => "Data jurusan Tidak Ditemukan",
            ];
            return response()->json($fails, 404);
        }
    }
}
